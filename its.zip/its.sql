-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               9.0.1 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for laravel
CREATE DATABASE IF NOT EXISTS `laravel` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `laravel`;

-- Dumping structure for table laravel.failed_jobs
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravel.failed_jobs: ~0 rows (approximately)

-- Dumping structure for table laravel.genders
CREATE TABLE IF NOT EXISTS `genders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `gender_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravel.genders: ~3 rows (approximately)
INSERT INTO `genders` (`id`, `gender_name`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'Male', 1, NULL, NULL, NULL),
	(2, 'Female', 1, NULL, NULL, NULL),
	(3, 'Other', 1, NULL, NULL, NULL);

-- Dumping structure for table laravel.inspections
CREATE TABLE IF NOT EXISTS `inspections` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `inspector_id` bigint unsigned NOT NULL,
  `category_id` bigint unsigned NOT NULL,
  `date_of_joining` date NOT NULL,
  `status_id` bigint unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inspections_inspector_id_foreign` (`inspector_id`),
  KEY `inspections_category_id_foreign` (`category_id`),
  KEY `inspections_status_id_foreign` (`status_id`),
  KEY `inspections_created_by_foreign` (`created_by`),
  CONSTRAINT `inspections_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `inspection_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `inspections_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `inspections_inspector_id_foreign` FOREIGN KEY (`inspector_id`) REFERENCES `inspectors` (`id`) ON DELETE CASCADE,
  CONSTRAINT `inspections_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravel.inspections: ~3 rows (approximately)
INSERT INTO `inspections` (`id`, `inspector_id`, `category_id`, `date_of_joining`, `status_id`, `is_active`, `remarks`, `created_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(18, 1, 1, '2024-09-28', 3, 1, 'Testing', 1, '2024-09-25 00:42:52', '2024-10-09 23:39:46', NULL),
	(19, 3, 1, '2024-09-28', 1, 1, 'Testing....', 1, '2024-09-25 03:49:48', '2024-10-09 23:39:52', NULL),
	(20, 1, 2, '2024-09-07', 1, 1, '4ertyhty', 1, '2024-09-25 04:14:26', '2024-09-25 22:29:30', NULL),
	(21, 15, 7, '2024-10-26', 4, 1, 'Testing....', 1, '2024-10-13 22:32:44', '2024-10-13 22:32:44', NULL);

-- Dumping structure for table laravel.inspection_categories
CREATE TABLE IF NOT EXISTS `inspection_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravel.inspection_categories: ~7 rows (approximately)
INSERT INTO `inspection_categories` (`id`, `category_name`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'Inspector – Routine Inspection', 1, NULL, '2024-10-10 06:35:22', NULL),
	(2, 'Headquarters Staff – Routine Inspection', 1, NULL, '2024-09-26 05:14:58', NULL),
	(3, 'Inspection Assistant – Routine Inspection', 1, NULL, '2024-09-26 05:14:58', NULL),
	(4, 'Inspector – Challenge Inspection', 1, NULL, '2024-09-26 05:15:02', NULL),
	(5, 'Headquarters Staff – Challenge Inspection', 1, NULL, '2024-09-26 05:15:00', NULL),
	(6, 'Inspection Assistant – Challenge Inspection', 1, NULL, '2024-09-26 05:15:03', NULL),
	(7, 'Test category Name ok', 1, '2024-09-26 04:22:56', '2024-09-26 05:15:06', NULL);

-- Dumping structure for table laravel.inspection_types
CREATE TABLE IF NOT EXISTS `inspection_types` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravel.inspection_types: ~2 rows (approximately)
INSERT INTO `inspection_types` (`id`, `type_name`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'Schedule 2', 1, NULL, NULL, NULL),
	(2, 'Schedule 3', 1, NULL, NULL, NULL);

-- Dumping structure for table laravel.inspectors
CREATE TABLE IF NOT EXISTS `inspectors` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender_id` bigint unsigned NOT NULL,
  `dob` date NOT NULL,
  `nationality_id` bigint unsigned NOT NULL,
  `place_of_birth` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `passport_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `unlp_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rank_id` bigint unsigned NOT NULL,
  `qualifications` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `professional_experience` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clearance_certificate` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inspectors_passport_number_unique` (`passport_number`),
  KEY `inspectors_gender_id_foreign` (`gender_id`),
  KEY `inspectors_nationality_id_foreign` (`nationality_id`),
  KEY `inspectors_rank_id_foreign` (`rank_id`),
  CONSTRAINT `inspectors_gender_id_foreign` FOREIGN KEY (`gender_id`) REFERENCES `genders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `inspectors_nationality_id_foreign` FOREIGN KEY (`nationality_id`) REFERENCES `nationalities` (`id`) ON DELETE CASCADE,
  CONSTRAINT `inspectors_rank_id_foreign` FOREIGN KEY (`rank_id`) REFERENCES `ranks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravel.inspectors: ~15 rows (approximately)
INSERT INTO `inspectors` (`id`, `name`, `gender_id`, `dob`, `nationality_id`, `place_of_birth`, `passport_number`, `unlp_number`, `rank_id`, `qualifications`, `professional_experience`, `clearance_certificate`, `remarks`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'Sh. H.S.P. Singh', 1, '2001-09-02', 78, 'Delhi', 'JHGJH6765765', 'NBMNB675765', 12, 'B.Tech', '2 Years', 'clearance_certificates/u8I4GfVvMyIAuoyBjKphgHb67w6GI6WP44zTbLsa.pdf', 'fgfgfg', 1, '2024-09-17 06:29:06', '2024-10-13 23:34:18', '2024-10-13 23:34:18'),
	(2, 'Sh. Neerav Kumar', 1, '2001-09-01', 3, 'Delhi', 'JHGJ5555555', 'JHGJH7786', 13, 'B.Tech', '3 Years', 'clearance_certificates/Hh6AVARW8RkOhEk6E1z67vKQvRJpeV47evTJS6m6.pdf', 'gbggf', 0, '2024-09-17 23:46:53', '2024-10-14 06:41:54', NULL),
	(3, 'Sh. Sunil Kumar Sharma', 1, '1999-09-01', 78, 'Delhi', 'JHGJH6765765555', 'JHGJH7786', 2, 'B.Tech', '2 Years', 'clearance_certificates/1rGnInqvW3xG3NSy5VrubxypxYNEUF3Hk6lLoIJc.pdf', 'Testing', 0, '2024-09-18 01:32:35', '2024-10-10 03:10:36', NULL),
	(4, 'Sh. Hari Kishan', 2, '2001-09-01', 78, 'Delhi', 'GHFHGF675675', 'JHGJH7786', 1, 'B.Tech', '2 Years', 'clearance_certificates/nTWNHuU0aR2Akad8PoinnGwhnCBMuUDZS92BCQWr.pdf', 'test', 0, '2024-09-18 01:59:43', '2024-09-26 03:02:48', NULL),
	(5, 'Smt. Monika Bhardwaj', 1, '1988-02-02', 78, 'Mumbai', 'GKUFG782828', 'NBMNB675765', 1, 'B.Tech', '2 Years', 'clearance_certificates/sjPJPIZWMUt2n08Dm7LwaSCIQUEu11n0oRGAuErx.pdf', 'Testing Expert', 1, '2024-09-18 04:53:57', '2024-09-26 01:47:13', NULL),
	(6, 'Sh. Ritu Raj', 1, '2000-03-18', 78, 'Delhi', 'JHJHG76576', 'HGJHG78876', 4, 'B.Tech', '2 Years', 'clearance_certificates/4pVnzI2SG6VtRSLKIUf5CU3K56qB8lvKrvCIX0q1.pdf', 'Testing', 0, '2024-09-18 05:17:26', '2024-10-10 06:39:47', NULL),
	(7, 'Sh. Harish Chander', 1, '2001-04-07', 78, 'Mumbai', 'GHFHGF6756754', 'NBMNB675765', 2, 'B.Tech', '2 Years', 'clearance_certificates/FRdAIFZwuqKa7IjwwY0VSZlE1ooWpY2XY4Ke7K5F.pdf', 'Testing...', 0, '2024-09-23 00:21:25', '2024-10-10 06:39:52', NULL),
	(8, 'Sh. Uma Shankar', 1, '2001-04-07', 78, 'Delhi', 'JHGJHGJ65675', 'JHGJH7786', 3, 'B.Tech', '2 Years', 'clearance_certificates/9SQRfFYpaZmqIORE2GuZKqWpV8vl0tGiH3WyCZle.pdf', 'Testing/...', 1, '2024-09-23 00:22:25', '2024-09-26 01:30:04', NULL),
	(9, 'Sh. Surender Kumar Yadav', 1, '2001-02-08', 78, 'Mumbai', 'JHJHG765763', 'NBMNB675765', 2, 'B.Tech', '2 Years', 'clearance_certificates/aurZMLkykdxGDWNKBk3CCGtXvIIR3kNWw2FUck5I.pdf', 'DFGHJ', 0, '2024-09-23 00:23:05', '2024-09-23 00:23:05', NULL),
	(10, 'Sh. Jogender Singh', 1, '2002-08-08', 78, 'Mumbai', 'JHGJH676576533', 'HGJHG78876', 3, 'B.Tech', '2 Years', 'clearance_certificates/RdS1Axnae8Un862Z3lMBRKFhkLZETyenU5I7wgUG.pdf', 'DFGH', 0, '2024-09-23 00:23:43', '2024-10-10 06:39:57', NULL),
	(11, 'Sh. Aishvir Singh', 1, '1999-06-06', 78, 'Mumbai', 'JHJHG7657622', 'NBMNB675765', 3, 'B.Tech', '2 Years', 'clearance_certificates/tBa0VQrmeNkc8qJHVeeOPLut7v54vVgfi08KRCoq.pdf', 'sdfgh', 0, '2024-09-23 00:24:22', '2024-10-10 06:40:01', NULL),
	(12, 'Sh. Sameer Srivastava', 1, '2001-09-02', 78, 'Delhi', 'JHGJH6', 'JHGJH7786', 1, 'B.Tech', '2 Years', 'clearance_certificates/cOx0V4oycBSBJP552KxACRzMlG6GA9tnk81zPTo3.pdf', 'Twesting', 0, '2024-09-23 22:28:25', '2024-09-25 00:18:18', NULL),
	(13, 'Sh. Vijay Pal', 1, '2006-05-24', 78, 'Delhi', 'HJG57657', 'JHGJH7786', 2, 'B.Tech', '2 Years', NULL, 'Tetsting', 0, '2024-09-24 00:06:15', '2024-09-25 00:18:23', NULL),
	(14, 'Sh. Ram Kumar', 1, '2001-09-21', 78, 'Delhi', 'JHGJH676', 'JHGJH7786', 2, 'B.Tech', '2 Years', 'clearance_certificates/YfWHsYHyAWtFE0Jvzn1TDB48Uu1HfNmqnFVLeKb9.pdf', 'bnm', 1, '2024-09-25 04:21:24', '2024-09-25 04:22:01', NULL),
	(15, 'Harsh', 1, '2001-04-07', 78, 'Delhi', 'HJG576577', 'HGJHG78876', 12, 'Test', 'Test', 'clearance_certificates/OelCRUpOopXlM3263HABm0TDMFWtSBK1fs1hze0A.pdf', 'Tewst', 1, '2024-10-10 00:28:47', '2024-10-10 00:28:47', NULL);

-- Dumping structure for table laravel.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=240 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravel.migrations: ~27 rows (approximately)
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(17, '2024_09_11_045424_create_inspectors_table', 2),
	(19, '2024_09_11_050432_create_visits_table', 4),
	(30, '2024_09_10_063720_create_inspections_table', 14),
	(33, '2024_09_11_110510_add_deleted_at_to_visits_table', 17),
	(192, '2024_09_11_200811_create_inspectors_table', 19),
	(213, '2014_10_12_100000_create_password_reset_tokens_table', 20),
	(214, '2019_08_19_000000_create_failed_jobs_table', 20),
	(215, '2019_12_14_000001_create_personal_access_tokens_table', 20),
	(216, '2024_09_10_063422_create_roles_table', 20),
	(217, '2024_09_10_063433_create_permissions_table', 20),
	(218, '2024_09_10_063509_create_permission_role_table', 20),
	(219, '2024_09_10_063530_create_permission_router_table', 20),
	(221, '2024_09_11_050603_create_opcw_faxes_table', 20),
	(222, '2024_09_11_055811_create_genders_table', 20),
	(223, '2024_09_11_060022_create_nationalities_table', 20),
	(224, '2024_09_11_060954_create_ranks_table', 20),
	(225, '2024_09_11_061005_create_statuses_table', 20),
	(226, '2024_09_11_061020_create_inspection_categories_table', 20),
	(227, '2024_09_11_061034_create_inspection_types_table', 20),
	(228, '2024_09_11_095007_create_inspectors_table', 20),
	(229, '2024_09_11_095008_create_inspections_table', 20),
	(230, '2024_09_11_112349_create_visits_table', 20),
	(231, '2014_10_12_000000_create_users_table', 21),
	(232, '2024_09_11_045459_create_reports_table', 22),
	(233, '2024_10_08_115853_add_created_by_to_inspections_table', 23),
	(234, '2024_10_09_064401_create_visit_categories_table', 24),
	(238, '2024_10_10_052030_add_category_id_to_visits_table', 25),
	(239, '2024_10_10_071054_modify_visits_table', 25);

-- Dumping structure for table laravel.nationalities
CREATE TABLE IF NOT EXISTS `nationalities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `country_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravel.nationalities: ~105 rows (approximately)
INSERT INTO `nationalities` (`id`, `country_name`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'Afghanistan', 1, NULL, '2024-10-09 23:11:07', '2024-10-09 23:11:07'),
	(2, 'Albania', 0, NULL, '2024-09-25 23:02:56', NULL),
	(3, 'Algeria', 0, NULL, '2024-09-25 23:02:56', NULL),
	(4, 'Andorra', 1, NULL, NULL, NULL),
	(5, 'Angola', 1, NULL, NULL, NULL),
	(6, 'Antigua and Barbuda', 1, NULL, NULL, NULL),
	(7, 'Argentina', 1, NULL, NULL, NULL),
	(8, 'Armenia', 1, NULL, NULL, NULL),
	(9, 'Australia', 1, NULL, NULL, NULL),
	(10, 'Austria', 1, NULL, NULL, NULL),
	(11, 'Azerbaijan', 1, NULL, NULL, NULL),
	(12, 'Bahamas', 1, NULL, NULL, NULL),
	(13, 'Bahrain', 1, NULL, NULL, NULL),
	(14, 'Bangladesh', 1, NULL, NULL, NULL),
	(15, 'Barbados', 1, NULL, NULL, NULL),
	(16, 'Belarus', 1, NULL, NULL, NULL),
	(17, 'Belgium', 1, NULL, NULL, NULL),
	(18, 'Belize', 1, NULL, NULL, NULL),
	(19, 'Benin', 1, NULL, NULL, NULL),
	(20, 'Bhutan', 1, NULL, NULL, NULL),
	(21, 'Bolivia', 1, NULL, NULL, NULL),
	(22, 'Bosnia and Herzegovina', 1, NULL, NULL, NULL),
	(23, 'Botswana', 1, NULL, NULL, NULL),
	(24, 'Brazil', 1, NULL, NULL, NULL),
	(25, 'Brunei', 1, NULL, NULL, NULL),
	(26, 'Bulgaria', 1, NULL, NULL, NULL),
	(27, 'Burkina Faso', 1, NULL, NULL, NULL),
	(28, 'Burundi', 1, NULL, NULL, NULL),
	(29, 'Cambodia', 1, NULL, NULL, NULL),
	(30, 'Cameroon', 1, NULL, NULL, NULL),
	(31, 'Canada', 1, NULL, NULL, NULL),
	(32, 'Cape Verde', 1, NULL, NULL, NULL),
	(33, 'Central African Republic', 1, NULL, NULL, NULL),
	(34, 'Chad', 1, NULL, NULL, NULL),
	(35, 'Chile', 1, NULL, NULL, NULL),
	(36, 'China', 1, NULL, NULL, NULL),
	(37, 'Colombia', 1, NULL, NULL, NULL),
	(38, 'Comoros', 1, NULL, NULL, NULL),
	(39, 'Congo (Brazzaville)', 1, NULL, NULL, NULL),
	(40, 'Congo (Kinshasa)', 1, NULL, NULL, NULL),
	(41, 'Costa Rica', 1, NULL, NULL, NULL),
	(42, 'Côte d\'Ivoire', 1, NULL, NULL, NULL),
	(43, 'Croatia', 1, NULL, NULL, NULL),
	(44, 'Cuba', 1, NULL, NULL, NULL),
	(45, 'Cyprus', 1, NULL, NULL, NULL),
	(46, 'Czech Republic', 1, NULL, NULL, NULL),
	(47, 'Denmark', 1, NULL, NULL, NULL),
	(48, 'Djibouti', 1, NULL, NULL, NULL),
	(49, 'Dominica', 1, NULL, NULL, NULL),
	(50, 'Dominican Republic', 1, NULL, NULL, NULL),
	(51, 'East Timor', 1, NULL, NULL, NULL),
	(52, 'Ecuador', 1, NULL, NULL, NULL),
	(53, 'Egypt', 1, NULL, NULL, NULL),
	(54, 'El Salvador', 1, NULL, NULL, NULL),
	(55, 'Equatorial Guinea', 1, NULL, NULL, NULL),
	(56, 'Eritrea', 1, NULL, NULL, NULL),
	(57, 'Estonia', 1, NULL, NULL, NULL),
	(58, 'Ethiopia', 1, NULL, NULL, NULL),
	(59, 'Fiji', 1, NULL, NULL, NULL),
	(60, 'Finland', 1, NULL, NULL, NULL),
	(61, 'France', 1, NULL, NULL, NULL),
	(62, 'Gabon', 1, NULL, NULL, NULL),
	(63, 'Gambia', 1, NULL, NULL, NULL),
	(64, 'Georgia', 1, NULL, NULL, NULL),
	(65, 'Germany', 1, NULL, NULL, NULL),
	(66, 'Ghana', 1, NULL, NULL, NULL),
	(67, 'Greece', 1, NULL, NULL, NULL),
	(68, 'Grenada', 1, NULL, NULL, NULL),
	(69, 'Guatemala', 1, NULL, NULL, NULL),
	(70, 'Guinea', 1, NULL, NULL, NULL),
	(71, 'Guinea-Bissau', 1, NULL, NULL, NULL),
	(72, 'Guyana', 1, NULL, NULL, NULL),
	(73, 'Haiti', 1, NULL, NULL, NULL),
	(74, 'Holy See (Vatican City)', 1, NULL, NULL, NULL),
	(75, 'Honduras', 1, NULL, NULL, NULL),
	(76, 'Hungary', 1, NULL, NULL, NULL),
	(77, 'Iceland', 1, NULL, NULL, NULL),
	(78, 'India', 1, NULL, NULL, NULL),
	(79, 'Indonesia', 1, NULL, NULL, NULL),
	(80, 'Iran', 1, NULL, NULL, NULL),
	(81, 'Iraq', 1, NULL, NULL, NULL),
	(82, 'Ireland', 1, NULL, NULL, NULL),
	(83, 'Israel', 1, NULL, NULL, NULL),
	(84, 'Italy', 1, NULL, NULL, NULL),
	(85, 'Jamaica', 1, NULL, NULL, NULL),
	(86, 'Japan', 1, NULL, NULL, NULL),
	(87, 'Jordan', 1, NULL, NULL, NULL),
	(88, 'Kazakhstan', 1, NULL, NULL, NULL),
	(89, 'Kenya', 1, NULL, NULL, NULL),
	(90, 'Kiribati', 1, NULL, NULL, NULL),
	(91, 'Kosovo', 1, NULL, NULL, NULL),
	(92, 'Kuwait', 1, NULL, NULL, NULL),
	(93, 'Kyrgyzstan', 1, NULL, NULL, NULL),
	(94, 'Laos', 1, NULL, NULL, NULL),
	(95, 'Latvia', 1, NULL, NULL, NULL),
	(96, 'Lebanon', 1, NULL, NULL, NULL),
	(97, 'Lesotho', 1, NULL, NULL, NULL),
	(98, 'Liberia', 1, NULL, NULL, NULL),
	(99, 'Libya', 1, NULL, NULL, NULL),
	(100, 'Liechtenstein', 1, NULL, NULL, NULL),
	(101, 'Lithuania', 1, NULL, NULL, NULL),
	(102, 'Luxembourg', 1, NULL, NULL, NULL),
	(103, 'Madagascar', 1, NULL, NULL, NULL),
	(104, 'Malawi', 1, NULL, NULL, NULL),
	(105, 'fdfgdfg', 1, '2024-09-25 22:59:38', '2024-09-25 22:59:38', NULL);

-- Dumping structure for table laravel.opcw_faxes
CREATE TABLE IF NOT EXISTS `opcw_faxes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `fax_date` date NOT NULL,
  `fax_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravel.opcw_faxes: ~5 rows (approximately)
INSERT INTO `opcw_faxes` (`id`, `fax_date`, `fax_number`, `reference_number`, `remarks`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, '2024-09-24', '23016897', '24305000', 'test', 1, '2024-09-24 00:32:16', '2024-10-09 23:10:59', '2024-10-09 23:10:59'),
	(2, '2024-09-12', '72363-236236', '26623-222323', 'The telephonic transmission', 1, '2024-09-24 01:01:23', '2024-09-25 23:19:12', NULL),
	(3, '2024-09-21', 'HJGJHG7687', 'JHGJHG786876', 'asdcvbnm,', 1, '2024-09-25 05:32:32', '2024-09-25 23:43:31', NULL),
	(4, '2024-09-28', '54345-22262', '54322-2323', 'When a man is tired of London, he is tired of life.', 1, '2024-09-25 05:37:10', '2024-09-25 23:14:17', NULL),
	(5, '2024-09-28', 'sdfg', 'qqqqqqqqqqqqq', 'fgfdgdfgf', 0, '2024-09-25 05:53:00', '2024-09-25 23:15:14', '2024-09-25 23:15:14');

-- Dumping structure for table laravel.password_reset_tokens
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravel.password_reset_tokens: ~0 rows (approximately)

-- Dumping structure for table laravel.permissions
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravel.permissions: ~0 rows (approximately)

-- Dumping structure for table laravel.permission_role
CREATE TABLE IF NOT EXISTS `permission_role` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `permission_role_permission_id_foreign` (`permission_id`),
  KEY `permission_role_role_id_foreign` (`role_id`),
  CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravel.permission_role: ~0 rows (approximately)

-- Dumping structure for table laravel.permission_router
CREATE TABLE IF NOT EXISTS `permission_router` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `router` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `permission_id` bigint unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `permission_router_permission_id_foreign` (`permission_id`),
  CONSTRAINT `permission_router_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravel.permission_router: ~0 rows (approximately)

-- Dumping structure for table laravel.personal_access_tokens
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravel.personal_access_tokens: ~0 rows (approximately)

-- Dumping structure for table laravel.ranks
CREATE TABLE IF NOT EXISTS `ranks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `rank_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravel.ranks: ~15 rows (approximately)
INSERT INTO `ranks` (`id`, `rank_name`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'Sr. Demilitarization Officer (P-3)', 1, NULL, '2024-09-26 01:36:55', NULL),
	(2, 'Senior Policy Officer (P-4)', 1, NULL, '2024-09-26 01:08:50', NULL),
	(3, 'Inspector (D-1)', 0, NULL, '2024-09-26 00:02:58', NULL),
	(4, 'Inspector (D-2)', 0, NULL, '2024-09-26 00:26:10', NULL),
	(5, 'Inspector', 1, NULL, NULL, NULL),
	(6, 'Inspector (P-1)', 1, NULL, NULL, NULL),
	(7, 'Inspector (P-2)', 1, NULL, NULL, NULL),
	(8, 'Inspector (P-3)', 1, NULL, NULL, NULL),
	(9, 'Inspector (P-4)', 1, NULL, NULL, NULL),
	(10, 'Inspector (P-5)', 1, NULL, NULL, NULL),
	(11, 'Inspection Assistant (GS-5)', 1, NULL, NULL, NULL),
	(12, 'Inspection Assistant (GS-6)', 1, NULL, NULL, NULL),
	(13, 'Inspection Assistant (GS-7)', 1, NULL, NULL, NULL),
	(14, 'Test rank 2', 0, '2024-09-26 00:53:29', '2024-09-26 00:56:02', '2024-09-26 00:56:02'),
	(15, 'Test Rank', 0, '2024-09-26 01:37:15', '2024-09-26 01:40:21', NULL);

-- Dumping structure for table laravel.reports
CREATE TABLE IF NOT EXISTS `reports` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravel.reports: ~0 rows (approximately)
INSERT INTO `reports` (`id`, `description`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'All Ok', 1, '2024-09-25 06:11:03', '2024-09-25 06:26:16', NULL);

-- Dumping structure for table laravel.roles
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravel.roles: ~2 rows (approximately)
INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
	(1, 'Admin', '2024-09-17 06:23:58', '2024-09-17 06:23:58'),
	(2, 'User', '2024-09-20 06:58:59', '2024-09-20 06:59:02');

-- Dumping structure for table laravel.statuses
CREATE TABLE IF NOT EXISTS `statuses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `status_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravel.statuses: ~4 rows (approximately)
INSERT INTO `statuses` (`id`, `status_name`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'Objected', 0, NULL, '2024-09-26 03:56:07', NULL),
	(2, 'Precaution', 1, NULL, '2024-09-26 03:55:38', NULL),
	(3, 'Deleted', 1, NULL, '2024-09-26 03:55:35', NULL),
	(4, 'Test Status', 1, '2024-09-26 02:07:16', '2024-09-26 03:35:06', NULL);

-- Dumping structure for table laravel.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `inspector_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned DEFAULT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravel.users: ~2 rows (approximately)
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `inspector_id`, `role_id`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'Admin', 'admin@gmail.com', NULL, '$1$fTJ6Pkct$FiLHp5IqFHCnlGwbrAPSu0', 1, 1, NULL, '2024-09-20 06:36:55', '2024-09-20 06:36:59', NULL),
	(2, 'Sh. Neerav Kumar', 'neerav@gmail.com', NULL, '$2y$10$nC7eyGeKNOGPWT914vfD.eEghOQeQJL.kIRGGmYb/ePHzwQxmtJDC', 9, 2, NULL, '2024-09-20 06:57:17', '2024-09-20 06:57:34', NULL);

-- Dumping structure for table laravel.visits
CREATE TABLE IF NOT EXISTS `visits` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `inspector_id` bigint unsigned NOT NULL,
  `type_of_inspection_id` bigint unsigned NOT NULL,
  `category_id` bigint unsigned DEFAULT NULL,
  `visit_report` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_of_inspection` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `point_of_entry` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `purpose_of_visit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `arrival_datetime` datetime NOT NULL,
  `list_of_inspectors` text COLLATE utf8mb4_unicode_ci,
  `team_lead_id` bigint unsigned DEFAULT NULL,
  `departure_datetime` datetime NOT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `visits_inspector_id_foreign` (`inspector_id`),
  KEY `visits_type_of_inspection_id_foreign` (`type_of_inspection_id`),
  KEY `visits_team_lead_id_foreign` (`team_lead_id`),
  CONSTRAINT `visits_inspector_id_foreign` FOREIGN KEY (`inspector_id`) REFERENCES `inspectors` (`id`) ON DELETE CASCADE,
  CONSTRAINT `visits_team_lead_id_foreign` FOREIGN KEY (`team_lead_id`) REFERENCES `inspectors` (`id`) ON DELETE SET NULL,
  CONSTRAINT `visits_type_of_inspection_id_foreign` FOREIGN KEY (`type_of_inspection_id`) REFERENCES `inspection_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravel.visits: ~6 rows (approximately)
INSERT INTO `visits` (`id`, `inspector_id`, `type_of_inspection_id`, `category_id`, `visit_report`, `site_of_inspection`, `point_of_entry`, `purpose_of_visit`, `arrival_datetime`, `list_of_inspectors`, `team_lead_id`, `departure_datetime`, `remarks`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 9, 1, NULL, NULL, 'Vigyan Bhawan', 'Headquator', 'Testing', '2024-09-18 17:45:00', '"[\\"1\\",\\"3\\",\\"4\\"]"', 1, '2024-09-18 17:48:00', 'Testing', 1, '2024-09-18 06:44:20', '2024-10-13 23:35:10', '2024-10-13 23:35:10'),
	(2, 4, 1, NULL, NULL, 'Vigyan Bhawan', 'Headquator', 'Default Purpose', '2024-09-12 10:15:00', '"[\\"3\\",\\"4\\",\\"5\\"]"', 3, '2024-09-24 11:15:00', 'Testing', 1, '2024-09-23 23:16:07', '2024-10-10 03:08:02', NULL),
	(3, 1, 2, NULL, NULL, 'Vigyan Bhawan', 'Headquator', 's', '2024-09-24 17:46:00', '"[\\"1\\",\\"4\\"]"', 1, '2024-09-24 17:46:00', 'Testing', 0, '2024-09-24 06:46:26', '2024-09-26 06:06:11', NULL),
	(4, 4, 1, NULL, NULL, 'Vigyan Bhawan', 'Headquator', 's', '2024-09-25 09:43:00', '"[\\"1\\",\\"3\\"]"', 2, '2024-09-25 09:43:00', 'Testing', 1, '2024-09-24 22:43:47', '2024-09-25 05:03:02', NULL),
	(5, 14, 1, NULL, NULL, 'kjh', 'Headquator', 'Testing', '2024-09-25 16:06:00', '"[\\"9\\",\\"14\\"]"', 14, '2024-09-25 16:05:00', 'fgvhjsdfghjkl;', 1, '2024-09-25 05:03:54', '2024-09-25 05:04:41', NULL),
	(6, 15, 1, NULL, NULL, 'Vigyan Bhawan', 'Headquator', 'Default Purpose', '2024-10-10 13:07:00', '"[\\"9\\",\\"12\\",\\"15\\"]"', 15, '2024-10-10 13:07:00', 'Twsting', 1, '2024-10-10 02:07:38', '2024-10-10 02:07:38', NULL),
	(7, 15, 2, NULL, NULL, 'Vigyan Bhawan', 'Site Visit', 'Default Purpose', '2024-10-14 19:24:00', '"[\\"4\\",\\"5\\"]"', 3, '2024-10-14 17:27:00', 'Testing.....', 1, '2024-10-14 06:25:21', '2024-10-14 06:25:21', NULL),
	(8, 15, 1, 1, 'visit_reports/oWnIHdkYmVlWBecGACAjIeUmYqjSqzmcWM4EXqED.pdf', 'Vigyan Bhawan', 'Site Visit', 'Default Purpose', '2024-10-14 17:33:00', '"[\\"3\\",\\"5\\",\\"13\\",\\"15\\"]"', 3, '2024-10-14 17:30:00', 'Testing....', 1, '2024-10-14 06:30:06', '2024-10-14 06:30:06', NULL);

-- Dumping structure for table laravel.visit_categories
CREATE TABLE IF NOT EXISTS `visit_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table laravel.visit_categories: ~2 rows (approximately)
INSERT INTO `visit_categories` (`id`, `category_name`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'Category 2', '2024-10-09 23:05:59', '2024-10-09 23:31:44', NULL),
	(2, 'Category 1', '2024-10-09 23:31:23', '2024-10-09 23:44:33', NULL);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
